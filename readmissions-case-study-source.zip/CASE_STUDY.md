## Reducing 30-Day Readmissions

### A healthcare analytics case study

Chigozie Nkwopara | 4 October 2026

### 1. Organisation and dataset context

Meridian Health Network is a fictional case organisation representing a network of 130 US hospitals. The stakeholder exercise is simulated. No real interviews took place.

The analysis uses the Diabetes 130-US Hospitals for Years 1999-2008 dataset by John Clore, Krzysztof Cios, Jon DeShazo and Beata Strack, UCI Machine Learning Repository, DOI 10.24432/C5230J, licensed under CC BY 4.0. The raw extract contains 101,766 encounters involving 71,518 patients. Each included encounter lasts 1 to 14 days. These are historical research records, not Meridian operational records.

| Context | Detail |
| --- | --- |
| Setting | 130 US hospitals, historical records from 1999 to 2008 |
| Population | Inpatients with diabetes recorded as a diagnosis |
| Raw extract | 101,766 encounters, 71,518 patients |
| Analytical cohort | 69,987 patients, one eligible encounter each |
| Decision | How should limited post-discharge follow-up capacity be targeted? |
| Funding context | Illustrative US payer setting, including private insurance, Medicare and Medicaid |

### Executive findings

The selected cohort has a 9.0% recorded 30-day readmission rate. Prior inpatient use and discharge destination show the largest descriptive differences. The logistic model has modest discrimination: test AUC 0.65. At 20% follow-up capacity, it identifies approximately 37% of recorded readmissions. This is a planning scenario, not a chosen operating threshold.

The business case uses hypothetical inputs. It estimates potential avoided costs, not measured savings. Subgroup differences require investigation and local validation before any care-related use.

The risk model is a retrospective analytical prototype for portfolio demonstration. It has not been clinically validated, certified or approved for patient-care decisions.

## 2. Stakeholder discovery

I designed a discovery questionnaire for four roles: Director of Clinical Operations, discharge planning leads, diabetes clinical lead and finance director. This simulated exercise demonstrates how an engagement could be scoped. It does not present invented stakeholder responses.

| Discovery question | Purpose | Proposed respondent |
| --- | --- | --- |
| What creates the greatest pressure on inpatient capacity? | Identify the business problem | Clinical Operations |
| Which outcomes create operational or financial concern? | Establish priorities | Clinical Operations and Finance |
| Where could the team intervene in the patient pathway? | Find decision points | Discharge Planning and Diabetes Lead |
| How is readmission risk identified today? | Understand current process | Discharge Planning |
| Who receives follow-up after discharge? | Identify targeting gaps | Discharge Planning |
| What limits follow-up capacity? | Establish constraints | Discharge Planning and Finance |
| Which measures would show an intervention worked? | Define success | All four roles |
| What evidence is needed before changing discharge processes? | Define analytical requirements | Clinical Operations and Diabetes Lead |

The questionnaire provides a framework for the assumed requirements in section 4. Actual needs, capacity and acceptance criteria would need confirmation with stakeholders in a real engagement.

### 3. Business problem and objectives

The fictional scenario assumes pressure from unplanned readmissions, bed demand and financial exposure. The historical outcome records early readmission but does not establish whether each return was unplanned, avoidable or subject to a payer penalty.

Decision question: which patients have greater recorded 30-day readmission risk, which factors identify them, and how might limited follow-up capacity be targeted?

1. Describe readmission frequency and length of stay.

2. Assess associations between readmission and patient, admission and discharge factors.

3. Describe recorded inpatient HbA1c testing variation, without assuming every patient required testing during that encounter.

4. Evaluate whether a simple model can support retrospective risk ranking and capacity planning.

## 4. Stakeholders, decisions and requirements

| Stakeholder / challenge | Decision | Analytical requirement | Success measure / evidence |
| --- | --- | --- | --- |
| Clinical Operations: bed and staff demand | Where should resources go? | Identify associations with readmission | Group rates, confidence intervals and effect sizes; sections 7-8 |
| Discharge Planning: limited follow-up capacity | Who could receive follow-up? | Risk ranking with capacity scenarios | Recall, precision and lift at each capacity; section 8 |
| Diabetes Lead: possible monitoring variation | Should practice be reviewed? | Describe testing rates and outcome association | Testing variation and practical effect size; section 7 |
| Finance: intervention funding | Is a pilot economically justified? | Estimate eligible population and hypothetical benefit | Net benefit, cost per prevented readmission and break-even rate; section 9 |

Requirements are assumed for the fictional case. A live project would confirm the follow-up service, patient eligibility, capacity, outcome definition and decision owner before selecting a threshold.

### Acceptance criteria for a pilot

- Clinical and operational owners agree the target population, intervention and escalation route.

- The model is validated on current local data, including calibration and subgroup performance.

- Capacity scenarios show workload alongside expected capture, without equating capture with prevention.

- Finance validates avoidable costs, programme costs and intervention effectiveness.

- Governance review defines acceptable performance, monitoring and stopping criteria.

## 5. Data quality assessment

| Issue | Scale / analytical risk | Treatment |
| --- | --- | --- |
| Question-mark missing codes | Missing entries could be read as real categories | Read ? and None as absent values |
| Weight | 96.9% absent | Excluded from this scoped analysis |
| Glucose serum result | 94.7% not tested; absence is not an ordinary data error | Excluded from this model scope, not assumed to have no predictive information |
| Medical specialty | 49.1% absent | Excluded; acknowledge lost clinical context |
| Payer code | 39.6% absent | Excluded from model scope; may still matter in other questions |
| HbA1c result | 83.3% not tested in raw encounters | Recode as Not tested; retain test indicator |
| Death and hospice discharges | 2,423 encounters | Exclude deaths; exclude hospice to define this exploratory follow-up cohort |
| Repeated patients | 30,248 encounters beyond one per raw patient | Retain one lowest-ID eligible encounter per patient |
| Coded categories | Admission, discharge and ICD-9 fields need interpretation | Decode and document grouping |
| Invalid gender | 3 records | Exclude |

Hospice exclusion defines the study population. It does not mean hospice patients cannot be readmitted. Dropping incomplete fields also does not prove that they contain no useful signal.

![Analytical figure](outputs/figures/01_missing_data.png)

## 6. Data preparation

| Step | Encounters | Patients | Treatment |
| --- | --- | --- | --- |
| 0. Raw data | 101,766 | 71,518 |  |
| 1. Drop sparse columns | 101,766 | 71,518 | weight (96.9% missing), payer_code (39.6% missing), medical_specialty (49.1% missing), max_glu_serum (94.7% missing) |
| 2. Remove invalid gender | 101,763 | 71,515 |  |
| 3. Remove deaths and hospice discharges | 99,340 | 69,987 | discharge codes 11, 13, 14, 19, 20, 21 |
| 4. Keep lowest-ID eligible encounter per patient | 69,987 | 69,987 |  |
| 5. Decode codes and add derived fields | 69,987 | 69,987 | 12 new fields |

The final cohort contains 69,987 patients and 58 columns. The index encounter is the lowest-ID record remaining after the eligibility exclusions. Without admission dates, this is not asserted to be the chronologically first admission.

Derived fields include the early-readmission flag, age band and midpoint, HbA1c tested indicator, total prior visits, medication-change count, admission source group, discharge group and primary diagnosis group.

![Analytical figure](outputs/figures/02_cleaning_funnel.png)

### Discharge coding correction

Hospital, rehab or other inpatient transfer includes codes 2, 5, 10, 15, 22, 23, 27, 28, 29 and 30. Codes 9, 12, 16 and 17 are kept in a separate other-care-status/outpatient-referral group. The latter has 22 index encounters and is too small for firm interpretation. It is omitted from the selected-factor forest plot, but retained in the model and full odds-ratio table.

## 6.1 Analysis-ready fields and cohort limits

| Field | Meaning |
| --- | --- |
| readmitted_30 | Recorded readmitted value &lt;30, binary outcome |
| time_in_hospital | Encounter length of stay, 1 to 14 days |
| age_band / age_mid | Ten-year age category and midpoint |
| gender / race | Recorded demographic categories; race used in subgroup checks, not prediction |
| admission_type / admission_source_group | Decoded admission categories |
| discharge_group | Grouped discharge destination or status |
| primary_diagnosis_group | Grouped primary ICD-9 diagnosis |
| number_inpatient / number_emergency / number_outpatient | Recorded encounters in the preceding year |
| num_lab_procedures / num_medications / number_diagnoses | Recorded tests, distinct medications and diagnoses |
| a1c_tested | HbA1c measurement recorded during this encounter |
| med_changes / insulin / diabetesMed | Recorded medication changes and treatment categories |

The readmission rate changes from 11.2% in raw encounters to 9.0% in the selected cohort. Patients with repeated records have a 19.8% encounter-level rate, compared with 4.3% for patients represented once. This comparison is descriptive and affected by how patients enter each group.

Recurrent admissions remain part of the operational problem. One encounter per patient avoids within-patient overlap between training and test sets, but discards longitudinal patterns and changes the target population. Production analysis should retain longitudinal encounters with patient-grouped validation or repeated-measures methods.

![Analytical figure](outputs/figures/03_repeat_patient_effect.png)

Reproducibility: 01_clean_data.py writes the cleaned data and cleaning log. 02_visualise_cleaning.py uses those outputs, so changes to eligibility flow through to the cleaning charts.

## 7. Analysis approach

| Objective | Methods | Output |
| --- | --- | --- |
| Readmission and length of stay | Proportions, confidence intervals, median, mean, IQR and percentiles | Outcome rate and stay profile |
| Factors associated with readmission | Chi-square, Cramer V, Mann-Whitney U, Welch t-test, Cohen d and Spearman correlation | Group comparisons and practical magnitude |
| HbA1c testing variation | Subgroup proportions and descriptive funnel plot | Recorded testing variation, not an adherence judgement |
| Retrospective risk ranking | Logistic regression, cross-validation, ROC-AUC, AP, Brier score, calibration and capacity metrics | Risk strata, workload scenarios and subgroup checks |

Tools demonstrated: Python, pandas, NumPy, SciPy, scikit-learn, statsmodels, Matplotlib and Pillow. The pipeline also produces a local scored CSV suitable for Power BI. A Power BI dashboard and SQL scripts are not included.

### 7.1 Descriptive findings

Readmission is 9.0% (95% CI 8.8% to 9.2%) in the selected cohort. Length of stay is right-skewed: median 3 days, mean 4.3 days and 90th percentile 8 days. Report the median alongside the distribution and mean when useful for resource planning.

![Analytical figure](outputs/figures/04_kpi_summary.png)

![Analytical figure](outputs/figures/05_length_of_stay_distribution.png)

## 7.2 Readmission patterns

Readmitted patients have a median index-encounter stay of 4 days, compared with 3 days for those not recorded as readmitted. Prior inpatient use shows a marked gradient: 8.1% with no prior stays and 29.3% with four or more. These are associations, not evidence that prior stays cause readmission.

![Analytical figure](outputs/figures/06_length_of_stay_by_outcome.png)

![Analytical figure](outputs/figures/07_readmission_by_prior_stays.png)

The corrected discharge-transfer category combines short-term hospital, rehab and other inpatient destinations. Its higher readmission rate supports reviewing transfer pathways, but does not isolate the effect of rehab or care quality.

![Analytical figure](outputs/figures/08_readmission_by_discharge.png)

## 7.3 Length of stay, age and diagnosis

Recorded readmission rises from 7.2% for stays of 1 to 2 days to 11.8% for stays of 8 to 14 days. Age and diagnosis show smaller descriptive differences. Age bands are ten-year intervals, so labels such as 70 to 80 mean ages 70 through 79.

![Analytical figure](outputs/figures/11_readmission_by_length_of_stay.png)

![Analytical figure](outputs/figures/09_readmission_by_age.png)

![Analytical figure](outputs/figures/10_readmission_by_diagnosis.png)

## 7.4 HbA1c testing variation

Only 18.4% of selected patients have an HbA1c measurement recorded during their encounter. Their readmission rate is 8.4%, compared with 9.1% for patients without a recorded measurement. Among tested patients, 49% have a result above 8%. This is a descriptive result for a selected tested population, not an estimate for all patients.

![Analytical figure](outputs/figures/12_hba1c_testing.png)

Testing varies by admission route, age and primary diagnosis. Patients admitted primarily for diabetes have a recorded testing rate of 35.9%. Elective and musculoskeletal groups have rates around 10%. A lower inpatient rate does not establish missed necessary care because recent external results, eligibility and clinical reasons are unavailable.

![Analytical figure](outputs/figures/20_hba1c_funnel.png)

The funnel is descriptive. Its groups overlap across dimensions, the overall rate is estimated from the same cohort, and limits do not adjust for case mix or multiple comparisons. Points beyond nominal limits identify groups for review, not proof of inadequate care or differences unexplained by chance.

| Dimension / group | Patients | Testing rate | Descriptive z |
| --- | --- | --- | --- |
| Admission type: Elective | 13,786 | 10.4% | -24.2 |
| Primary diagnosis: Musculoskeletal | 4,064 | 9.9% | -13.9 |
| Age: 70 to 80 | 17,749 | 15.0% | -11.5 |
| Age: 80 to 90 | 11,110 | 14.6% | -10.2 |
| Age: 40 to 50 | 6,828 | 24.9% | 14.0 |
| Primary diagnosis: Diabetes | 5,748 | 35.9% | 34.3 |

## 7.5 Statistical tests and effect sizes

Nine of ten categorical factors remain associated with readmission after Benjamini-Hochberg adjustment across those ten comparisons. Recorded gender does not. Large samples can detect small associations, so practical magnitude matters more than significance alone.

![Analytical figure](outputs/figures/13_effect_sizes.png)

| Factor | Cramer V | FDR-adjusted p |
| --- | --- | --- |
| Discharge destination | 0.120 | &lt;0.001 |
| Prior inpatient stays | 0.098 | &lt;0.001 |
| Length of index encounter | 0.059 | &lt;0.001 |
| Age band | 0.052 | &lt;0.001 |
| Primary diagnosis | 0.033 | &lt;0.001 |
| Race | 0.016 | 0.004 |
| Admission type | 0.014 | 0.043 |
| Admission source | 0.011 | 0.043 |
| HbA1c tested | 0.010 | 0.016 |
| Gender | 0.002 | 0.590 |

Discharge destination and prior inpatient use have the largest categorical effect sizes, both around 0.1. HbA1c testing has a negligible effect size of approximately 0.010. Statistical association does not establish clinical benefit from testing.

## 7.6 Numeric comparisons and correlation

| Measure | Median: readmitted / other | Mean: readmitted / other | Cohen d |
| --- | --- | --- | --- |
| Length of stay (days) | 4 / 3 | 4.79 / 4.22 | 0.20 |
| Medications | 15 / 14 | 16.62 / 15.57 | 0.13 |
| Diagnoses recorded | 8 / 8 | 7.51 / 7.20 | 0.16 |
| Lab procedures | 46 / 44 | 44.91 / 42.68 | 0.11 |
| Inpatient stays, prior year | 0 / 0 | 0.37 / 0.16 | 0.35 |
| Emergency visits, prior year | 0 / 0 | 0.15 / 0.10 | 0.10 |

Mann-Whitney U tests were used for skewed counts. Welch tests give the same broad significance conclusions. Numeric tests are exploratory and their p-values are not included in the ten-factor categorical FDR adjustment. Reported differences are small, with prior inpatient stays showing the largest standardised difference at about 0.35.

Spearman correlations between the selected numeric inputs and readmission are weak, with none above about 0.08. The largest examined pairwise correlation between inputs is 0.46, for length of stay and medication count. This does not establish that the full encoded design is free from multicollinearity. Further checks could include design-matrix diagnostics, coefficient stability and sensitivity to model specification.

| Input | Correlation with readmission |
| --- | --- |
| Length of stay | 0.06 |
| Lab procedures | 0.03 |
| Other procedures | 0.00 |
| Medications | 0.04 |
| Diagnoses | 0.04 |
| Prior inpatient stays | 0.09 |
| Prior emergency visits | 0.03 |
| Prior outpatient visits | 0.02 |
| Age | 0.05 |

## 8. Risk model and validation

The prespecified logistic model uses a stratified 70% training / 30% test split with random seed 42. The test set has 20,997 patients. Preprocessing is fitted within the model pipeline. Every patient appears once, so there is no within-patient overlap between training and test sets.

Inputs include prior inpatient, emergency and outpatient use, length of stay, medication and diagnosis counts, lab and procedure counts, age midpoint, medication changes, HbA1c testing, discharge group, admission source and type, diagnosis group, insulin, diabetes medication and recorded gender. Race is excluded from prediction and retained for subgroup evaluation.

Five-fold stratified cross-validation is performed across the full selected cohort. This is a separate stability exercise that overlaps the hold-out cohort. It is not an additional independent external validation. Future model selection should use training-only cross-validation and an untouched final test set, followed by temporal or external validation where feasible.

| Metric | Result | Interpretation |
| --- | --- | --- |
| Test ROC-AUC | 0.649 (95% bootstrap CI 0.635-0.662) | Modest discrimination; 1,000 test-set bootstrap resamples |
| Five-fold CV AUC | 0.642, SD 0.008 | Stability within this historical cohort |
| Average precision (AP) | 0.161; prevalence 0.090 | Summary of precision-recall performance, not precision at a chosen threshold |
| Brier score | 0.0797; null 0.0818 | Small probability-error improvement |
| Brier skill score | 2.5% | Relative improvement over prevalence-only prediction |
| Mean predicted / observed | 9.0% / 9.0% | Similar overall averages do not guarantee individual or subgroup calibration |

The results support exploratory risk ranking. They do not demonstrate clinical utility or suitability for individual care decisions. The AUC interval reflects test-sample uncertainty conditional on the fitted model, not the uncertainty of the entire training process.

![Analytical figure](outputs/figures/combined/D_discrimination_and_calibration.png)

Predicted and observed risks track reasonably closely across ten equal-sized risk groups. This supports approximate interpretation within this sample. It does not establish calibration for every individual, subgroup or new healthcare setting.

## 8.1 Follow-up capacity scenarios

Actual follow-up capacity is unknown. No single operating threshold is selected. The highest-risk decile has about a 20.1% readmission rate, compared with 3.9% in the lowest-risk decile. These are retrospective rates in the test cohort.

![Analytical figure](outputs/figures/15_lift_by_decile.png)

![Analytical figure](outputs/figures/18_capacity_curve.png)

| Capacity | Follow-ups per 1,000 | Recall | Precision | Lift |
| --- | --- | --- | --- | --- |
| 10.0% | 100 | 22.3% | 20.0% | 2.23 |
| 20.0% | 200 | 37.0% | 16.6% | 1.85 |
| 30.0% | 300 | 50.0% | 15.0% | 1.67 |
| 40.0% | 400 | 59.4% | 13.4% | 1.49 |

Capacity selection balances workload, intervention cost and desired outcome capture. Capturing a readmission means identifying a patient who later has that outcome. It does not mean the readmission could have been prevented.

## 8.2 Worked 20% scenario and adjusted associations

![Analytical figure](outputs/figures/16_confusion_matrix.png)

At this worked scenario, precision is 16.6% and recall is 37.0%. Most flagged patients do not have a recorded readmission, and most readmissions remain outside the flagged group. The scenario is useful for comparing workload, not as a standalone clinical rule.

The odds ratios come from an unpenalised statsmodels refit on the training design matrix. They describe adjusted associations. Numeric odds ratios are per training-set standard deviation, including the binary HbA1c indicator.

![Analytical figure](outputs/figures/17_odds_ratios.png)

Hospital, rehab or other inpatient transfer: OR 2.96, 95% CI 2.66-3.29. Nursing facility: OR 1.75, 95% CI 1.59-1.93. These results do not show that a destination causes higher readmission.

Categorical references: Home for discharge, Emergency room for admission source, Elective for admission type, Circulatory for diagnosis, Down for insulin, No for diabetes medication and Female for recorded gender. The forest plot displays selected factors, not the complete model. The full table is in outputs/tables/odds_ratios.csv.

## 8.3 Subgroup performance

Subgroups use a common threshold at the 20% scenario. Recorded sex/gender, race and age are assessed descriptively. African American and Caucasian patients have similar rounded observed readmission rates, but different flagging and recall. Similar rounded rates do not prove equal underlying risk or identify the cause of the difference.

| Group | n | Outcome rate | Flagged | Recall (95% CI) | Precision |
| --- | --- | --- | --- | --- | --- |
| Female | 11,247 | 8.9% | 21.4% | 39.2% (36.2%-42.2%) | 16.4% |
| Male | 9,750 | 9.0% | 18.4% | 34.4% (31.4%-37.6%) | 16.9% |
| African American | 3,780 | 9.1% | 14.9% | 32.4% (27.6%-37.5%) | 19.7% |
| Caucasian | 15,718 | 9.1% | 21.5% | 38.0% (35.5%-40.6%) | 16.1% |
| Other or unknown | 1,499 | 7.3% | 16.9% | 37.3% (28.8%-46.6%) | 16.2% |
| Under 60 | 7,055 | 7.0% | 9.7% | 27.4% (23.7%-31.6%) | 19.8% |
| 60 to 79 | 10,006 | 9.8% | 20.4% | 35.9% (33.0%-39.0%) | 17.2% |
| 80 and over | 3,936 | 10.6% | 37.6% | 50.6% (45.8%-55.4%) | 14.3% |

Recall intervals are Wilson binomial intervals conditional on this fitted model and threshold. They do not include training uncertainty or adjust for multiple subgroup comparisons. Differences should be assessed with sample size, calibration, clinical need and the consequences of missed follow-up.

### 8.4 Exploratory subgroup investigation

| Measure | African American | Caucasian |
| --- | --- | --- |
| patients | 3,780 | 15,718 |
| observed readmission | 9.1% | 9.1% |
| mean predicted risk | 8.4% | 9.2% |
| flagged share | 14.9% | 21.5% |
| mean age | 60.1 | 67.2 |
| under 60 share | 48.3% | 29.4% |
| any prior inpatient | 9.9% | 12.1% |
| discharged to nursing or rehab | 14.5% | 20.8% |

African American patients are younger on average and less often transferred to nursing or other inpatient care. These input differences may contribute to lower scores. The descriptive comparison does not quantify their causal contribution or establish a root cause.

![Analytical figure](outputs/figures/21_fairness_calibration.png)

In African American patients aged 60-79, mean predicted risk is lower than observed risk. The observed-outcome interval gives useful context but is not a formal test incorporating fitted-model uncertainty. Smaller intersectional groups have wider uncertainty.

Options for further evaluation include better risk-factor coverage, age interactions, recalibration and changes to the follow-up policy. Fit proposed remedies on separate training or validation data and assess their effects on calibration, capture, workload and subgroup outcomes before deployment. No single remedy is established by this exercise.

## 9. Recommendations and business case

| Priority | Proposed action | Evidence / owner |
| --- | --- | --- |
| 1 | Consider a capacity-matched follow-up pilot using a locally validated score, with a clinically agreed contact window | 20% scenario captures about 37% of recorded readmissions. Owner: Discharge Planning |
| 2 | Review handovers across hospital transfers, rehab and nursing pathways: medication list, care plan and named contact | Adjusted transfer and nursing associations. Owner: Clinical Operations |
| 3 | Assess case-management eligibility for patients with repeated prior inpatient use | Readmission gradient from 8.1% to 29.3%. Owner: Diabetes Lead |
| 4 | Review HbA1c measurement against applicable guidance and recent results; check eligible patients consistently | Testing variation does not itself prove missed care. Owner: Diabetes Lead |
| 5 | Investigate subgroup calibration and capture; test remedies on separate validation data | Exploratory subgroup differences. Owner: Analytics and clinical governance |
| 6 | Report stay distributions and median; monitor dated readmission outcomes with appropriate SPC methods | Current data lack admission dates. Owner: Analytics |

These are proposed pilot and review actions for the fictional scenario. They are not clinical instructions or evidence that an intervention has reduced readmissions.

### Illustrative economics

The financial scenarios are per 1,000 diabetic discharges at 20% capacity: 200 follow-ups. The number of recorded readmissions within that group is estimated from the test cohort. Prevention rates, follow-up costs and avoided cost per readmission are hypothetical.

### Financial scenarios

| Assumption / result | Conservative | Base | Optimistic |
| --- | --- | --- | --- |
| Follow-up cost per patient (hypothetical) | $150 | $100 | $75 |
| Share of flagged readmissions prevented (hypothetical) | 5.0% | 10.0% | 20.0% |
| Avoided cost per readmission (hypothetical) | $10,000 | $12,500 | $15,000 |
| Expected readmissions prevented | 1.7 | 3.3 | 6.6 |
| Follow-up programme cost | $30,000 | $20,000 | $15,000 |
| Gross avoided cost | $16,598 | $41,494 | $99,586 |
| Net avoided-cost benefit | -$13,402 | $21,494 | $84,586 |
| Cost per prevented readmission | $18,075 | $6,025 | $2,259 |
| Break-even prevention rate | 9.0% | 4.8% | 3.0% |

Calculation: expected prevented readmissions = readmissions in the flagged group x assumed prevention rate. Net benefit = expected prevented readmissions x assumed avoided cost - follow-up cost. Break-even prevention rate = follow-up cost / potential avoided cost if every flagged readmission were prevented.

The base scenario gives net avoided-cost benefit of $21,494 and breaks even at a 4.8% prevention rate. These are modelled estimates, not observed financial returns.

Avoided accounting cost is not necessarily cash-releasing savings. The model excludes setup, technology, administration, training and additional capacity costs. It assumes constant intervention effectiveness and unit costs across risk strata. Finance should replace these assumptions with marginal avoidable costs, the full programme budget and effectiveness evidence from a controlled pilot. Capacity comparisons are illustrative, not an estimated optimal service size.

## 10. Limitations and governance

| Limitation | Effect | Next step |
| --- | --- | --- |
| Historical US data, 1999-2008 | Care and coding may differ today | Validate on current local data |
| No admission dates | No verified chronological index, trend or temporal validation | Obtain dated extracts |
| Recorded early readmissions | May miss returns outside contributing systems; does not identify preventability | Confirm capture and link regional/national outcomes |
| Limited social and clinical context | Unmeasured determinants and residual confounding | Review clinically appropriate additional predictors |
| AUC about 0.65 | Modest discrimination; limited probability-error improvement | Evaluate utility and compare alternatives on separate validation data |
| Observational design | Associations do not establish causation | Pilot intervention with a suitable comparison group |
| Subgroup differences | Unequal capture and possible miscalibration | Investigate, assess uncertainty and validate proposed remedies |
| One eligible encounter per patient | Repeat-stay patterns and target population change | Use longitudinal data with grouped validation |
| Unadjusted overlapping testing groups | Funnel limits do not establish poor care | Assess eligibility, recent results, case mix and testing policy |

### Requirements before any live use

Data protection: this portfolio uses a publicly available research dataset and no identifiable NHS patient data. A live patient-level deployment needs an appropriate lawful basis, access controls, data minimisation and assessment of data-protection risks, including whether a DPIA is required. Real US use would require assessment of applicable federal and state requirements.

Clinical safety: the model is not intended for clinical use. If developed into a product influencing patient-level care in England, its intended use and applicability under DCB0129, DCB0160 and medical-device regulation need formal assessment. A tool should support clinically governed decisions, with an escalation route.

Fairness: assess calibration, recall, precision, false-positive rates and consequences across relevant groups. Investigate material differences and agree acceptable criteria with clinical and governance owners. Numerical parity alone does not establish fairness.

Monitoring: define an operational review schedule, drift checks, calibration checks, subgroup checks and clinical outcome review. Retraining requires validation and change approval rather than an automatic response to a single metric drop.

Transparency: document inputs, outcome definitions, exclusions, reference levels, intended use and limitations. Record how scores affect follow-up decisions. Establish accountability and stopping criteria before a pilot.

## 11. NHS application

The approach can be adapted to an NHS trust. Findings, outcome definitions, risk estimates and intervention assumptions need revalidation on current NHS data. This simulated project does not demonstrate actual NHS stakeholder interviews, statutory reporting or delivered service change.

| Case-study element | Possible NHS translation |
| --- | --- |
| Recorded early readmission | NHS England emergency-readmission indicator has its own eligibility rules, definitions and exclusions |
| Discharge transfer associations | Review intermediate care, community hospital, hospital-transfer and care-home pathways |
| Capacity-defined follow-up group | Clinically agreed community nursing, GP follow-up or other locally appropriate service |
| Repeated prior inpatient use | Assess high-intensity-user and integrated-care pathways |
| HbA1c testing variation | Review appropriate monitoring using NICE guidance and available recent results |
| Python analysis and local scored export | Adapt to local data platforms; SQL and Power BI are possible tools, not delivered artifacts here |

A seven-day contact window remains a proposed scenario. The clinical service should define timing and intervention eligibility. A risk score alone does not determine suitability for a virtual ward or another specific service.

### Source guidance

[UCI dataset and citation](https://doi.org/10.24432/C5230J)

[CC BY 4.0 licence](https://creativecommons.org/licenses/by/4.0/)

[NHS clinical-safety applicability](https://digital.nhs.uk/services/clinical-safety/applicability-of-dcb-0129-and-dcb-0160/step-by-step-guidance)

[MHRA intended-purpose guidance](https://www.gov.uk/government/publications/crafting-an-intended-purpose-in-the-context-of-software-as-a-medical-device-samd)

[NICE NG28 diabetes guidance](https://www.nice.org.uk/guidance/ng28)

[NHS emergency-readmissions indicator](https://digital.nhs.uk/data-and-information/publications/statistical/compendium-emergency-readmissions)

## 12. Technical deliverables

| Deliverable | Contents |
| --- | --- |
| run_all.py | Runs all seven steps in order |
| 01_clean_data.py | Eligibility, decoding, corrected discharge grouping and derived fields |
| 02_visualise_cleaning.py | Data-quality and cohort-flow charts |
| 03_descriptive_stats.py | Summary statistics and descriptive charts |
| 04_analysis.py | Exploratory tests, model, CV, adjusted odds ratios and local scored export |
| 05_model_evaluation.py | AUC interval, AP, Brier, capacity, financial scenarios and subgroup recall intervals |
| 06_further_analysis.py | Testing variation, correlations and exploratory subgroup investigation |
| 07_doc_figures.py | Combined report exhibits |
| style.py | Shared paths and chart styling |
| outputs/tables and outputs/figures | Aggregated results and charts |
| Locally generated scored CSV | 20,997 test patients for Power BI use; excluded from public ZIP |
| README, requirements and LICENSE | Run instructions, analytical limits, dependencies and code reuse terms |
| This PDF and report source | Revised case study and editable Markdown narrative |

Raw data and row-level outputs are not redistributed. Download the original data from UCI, place diabetic_data.csv and IDS_mapping.csv in data/raw, install requirements and run python run_all.py. The public package contains no Power BI dashboard or SQL scripts.

### Verification

The seven-step pipeline was rerun against the original UCI extract after the corrections. The report tables and figures use the regenerated outputs. Numerical changes from discharge regrouping are small but retained rather than replaced with previous values. Dependencies include Pillow explicitly.

### 13. Data source, licence and use

Dataset: [Diabetes 130-US Hospitals for Years 1999-2008](https://doi.org/10.24432/C5230J) by John Clore, Krzysztof Cios, Jon DeShazo and Beata Strack. UCI Machine Learning Repository. DOI 10.24432/C5230J. Licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The original data were cleaned, recoded, grouped and transformed. UCI and the dataset creators do not endorse this case study or the fictional Meridian Health Network scenario.

Citation: Clore, J., Cios, K., DeShazo, J., and Strack, B. (2014). Diabetes 130-US Hospitals for Years 1999-2008 [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5230J.

Meridian and its stakeholder exercise are fictional. No real stakeholder interviews were conducted. Financial assumptions are illustrative. The predictive model is a retrospective analytical prototype for portfolio demonstration. It has not been clinically validated, certified or approved for patient-care decisions. Any real use requires current local data, clinical validation, information-governance review, equality/fairness assessment, clinical-safety assessment and consideration of applicable medical-device requirements.
