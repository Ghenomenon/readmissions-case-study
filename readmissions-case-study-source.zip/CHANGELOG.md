# Publication revisions - 4 October 2026

- Corrected discharge categories and regenerated model, capacity, financial and subgroup outputs.
- Clarified lowest-ID index selection and hospice exclusion.
- Distinguished absent glucose testing from ordinary missing data.
- Removed unsupported collinearity, causal fairness and typical-performance claims.
- Defined average precision, categorical reference levels and cross-validation scope.
- Added Wilson confidence intervals for subgroup recall and descriptive funnel limitations.
- Qualified hypothetical costs, prevention assumptions and clinical recommendations.
- Removed unsupported dashboard and SQL deliverable claims.
- Added Pillow dependency, MIT code licence and editable report narrative.
- Retained CC BY attribution and conditional clinical-safety disclosures.
- Rebuilt and visually checked the 22-page PDF.

Validation: the full seven-step pipeline completed against the UCI source extract. Raw and row-level derivative data are excluded from this package.
