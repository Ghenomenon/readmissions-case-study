# Reducing 30-Day Readmissions: A Healthcare Analytics Case Study

A retrospective healthcare analytics case study demonstrating risk stratification and capacity-planning methods using historical public data.

Meridian Health Network is a fictional case organisation. Its stakeholder discovery exercise is simulated, and no real interviews took place. Financial assumptions are illustrative.

> **Not for clinical use.** The risk model is an analytical prototype for portfolio demonstration. It has not been clinically validated, certified or approved for patient-care decisions.

## What the project covers

- Stakeholder discovery and requirements traceability
- Data quality assessment and cleaning of 101,766 hospital encounters
- Descriptive statistics and FDR-adjusted exploratory tests
- Logistic regression risk model with cross-validation, calibration, PR-AUC and Brier score
- Follow-up capacity scenarios and a hypothetical business case
- Subgroup performance checks by sex, race and age, with an exploratory investigation of subgroup differences
- HbA1c testing variation by subgroup, using z-scores and a funnel plot

## How to run it

1. Download the dataset from the [UCI Machine Learning Repository](https://doi.org/10.24432/C5230J).
2. Unzip it and place `diabetic_data.csv` and `IDS_mapping.csv` in `data/raw/`.
3. Install the requirements and run the pipeline:

```
pip install -r requirements.txt
python run_all.py
```

The pipeline rebuilds the cleaned data, every chart and table, and a scored patient file for Power BI. Raw data and row-level outputs stay on your machine and are not part of this repository.

## Structure

| Path | Contents |
| --- | --- |
| `run_all.py` | Runs the seven steps in order |
| `src/01_clean_data.py` | Cleaning and derived fields |
| `src/02_visualise_cleaning.py` | Charts 01 to 03 |
| `src/03_descriptive_stats.py` | Charts 04 to 12 and summary tables |
| `src/04_analysis.py` | Statistical tests, risk model, charts 13 to 17 |
| `src/05_model_evaluation.py` | Calibration, capacity scenarios, subgroup checks, business case, charts 18 and 19 |
| `src/06_further_analysis.py` | HbA1c testing variation, correlations, subgroup investigation, charts 20 and 21 |
| `src/07_doc_figures.py` | Combined figures used in the written report |
| `src/style.py` | Shared paths and chart style |
| `outputs/figures/` | Charts |
| `outputs/tables/` | Aggregated result tables |

## Data source and licence

This project uses the [Diabetes 130-US Hospitals for Years 1999–2008](https://doi.org/10.24432/C5230J) dataset by John Clore, Krzysztof Cios, Jon DeShazo and Beata Strack, UCI Machine Learning Repository, DOI 10.24432/C5230J, licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). The source data were cleaned, recoded, grouped and transformed for this analysis. UCI and the dataset creators do not endorse this project or the fictional Meridian Health Network scenario.

Citation: Clore, J., Cios, K., DeShazo, J., and Strack, B. (2014). Diabetes 130-US Hospitals for Years 1999–2008 [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5230J

## Author

Chigozie Nkwopara · [GitHub](https://github.com/Ghenomenon) · [Portfolio](https://chigozie-nkwopara.netlify.app)

## Analytical choices and limits

- The index encounter is the lowest-ID eligible record per patient. Encounter IDs are not treated as verified admission dates.
- Death discharges are excluded. Hospice discharges are also excluded to define the exploratory follow-up cohort, not because readmission is impossible.
- Hospital, rehab or other inpatient transfer includes codes 2, 5, 10, 15, 22, 23, 27, 28, 29 and 30. Codes 9, 12, 16 and 17 form a separate other-care-status/outpatient-referral group.
- Glucose test absence means not tested. The glucose result field is excluded from this scoped model, rather than assumed to have no signal.
- Five-fold cross-validation uses the full cohort. The separate 30% test split evaluates a prespecified model; it is not independent of the cross-validation exercise. Future model selection needs training-only CV and an untouched final test set.
- Average precision is reported as AP, rather than precision at a threshold.
- Subgroup comparisons are exploratory. Recalibration is an option to evaluate on separate validation data, not an established remedy.
- Financial benefits use hypothetical avoided costs. They are not measured or guaranteed cash-releasing savings. Setup and administration costs are excluded.
- The native seven-page Power BI project is published separately at https://github.com/Ghenomenon/readmissions-powerbi. This pipeline supplies the local scored CSV needed to rebuild its patient data. No SQL scripts are included.

## Categorical reference levels

The encoder drops the first sorted category. Reference levels are Home (discharge), Emergency room (source), Elective (admission type), Circulatory (diagnosis), Down (insulin), No (diabetes medication) and Female (recorded gender). Numeric odds ratios are per training-set standard deviation, including the binary HbA1c tested field.

## Reuse

Original project code is provided under the MIT licence in LICENSE. The source dataset retains its separate CC BY 4.0 licence.

## Completed report

Read `docs/Readmissions-Case-Study-Final.pdf` or edit `CASE_STUDY.md`. All report metrics were refreshed after correcting discharge groups.
